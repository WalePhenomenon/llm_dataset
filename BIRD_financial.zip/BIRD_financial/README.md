# BIRD financial database (subset for SEAS 8515)

- `financial.sqlite`: the Czech retail-bank database from the BIRD benchmark dev set (PKDD'99 data), 8 tables.
- `database_description/*.csv`: BIRD's documentation of every column.
- `questions.json`: 10 questions from the BIRD Mini-Dev release of 2025-07-04 (SQLite), question IDs 89, 93, 100, 112, 117, 128, 136, 137, 168 and 192, with BIRD's evidence, gold SQL, and the result of running the gold SQL on this database.

BIRD is released under the Creative Commons Attribution-ShareAlike 4.0 International license (CC BY-SA 4.0), https://creativecommons.org/licenses/by-sa/4.0/. This subset is shared under the same license.

Li, J., Hui, B., Qu, G., et al. (2023). Can LLM Already Serve as a Database Interface? A BIg Bench for Large-Scale Database Grounded Text-to-SQLs. NeurIPS 2023. https://bird-bench.github.io/
